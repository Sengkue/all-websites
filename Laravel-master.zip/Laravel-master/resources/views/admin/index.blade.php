<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>skv-index</title>
</head>
<body>    
         <?php

         $user ="Sengkuevang";
         $skv = array("Apple","Orange","Mango","Banana");
         ?>

    <h1><center>Welcome to everyone! This is admin page </center></h1>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Vel molestiae corporis incidunt ipsum modi quia impedit accusantium ut nesciunt velit. Amet provident nemo facere quas. Sint dolorem cum fugit at.</p>
     <h1><center>You are special person: {{$user}}</center></strong></h1>

      @if( $user == "Sengkuevang")
            <h1>You are admin.</h1>
       @else
             <h1>But so sorry, You are not admin.</h1>
      @endif 

      @foreach($skv as $menu)
        <a href="#">{{$menu}}</a>
      @endforeach
      
      <ul>
      @for($i=1;$i<=10;$i++)
        
             <li>{{$i}}</li>
        
       @endfor   
       </ul>


       <h1><center>you live in : {{$address}}</center></h1>

</body>
</html>