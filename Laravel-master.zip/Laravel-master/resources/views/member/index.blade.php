<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><center>Hello this cumstome page</center></h1>
   <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta facere nesciunt quas, iste non labore enim dolorem autem cupiditate omnis harum blanditiis incidunt quisquam saepe ducimus, odit voluptatum magni modi!</p>
   <!-- <div>
       <ul> -->
           <!-- <li><a href="/">Home</a></li>
           <li><a href="/admin">admin</a></li>
           <li><a href="/member">about</a></li>
           <li><a href="#">contact</a></li> -->

           <!-- <li><a href="{{url('/')}}">Home</a></li>
           <li><a href="{{route('admin')}}">admin</a></li>
           <li><a href="{{url('about')}}">about</a></li>
           <li><a href="{{route('members')}}">member</a></li>
           
           
            <li>love</li>
       </ul> -->
   <!-- </div> -->

</body>
</html>