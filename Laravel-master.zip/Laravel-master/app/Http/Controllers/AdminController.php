<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
   function index(){
        $city = "12334 pakading , Laos pdr"; 

       return view('admin.index',['address'=>$city]);
   } 
}
